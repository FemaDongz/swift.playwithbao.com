=== CARA MEMBUAT PNG KARAKTER ===

Buat 5 file PNG ukuran 16x16 pixel (atau 10x10) di folder ini:

1. james.png  (\\uE003) - Karakter laki-laki
2. sarah.png  (\\uE004) - Karakter perempuan ceria
3. rin.png    (\\uE005) - Karakter perempuan tomboy
4. kai.png    (\\uE006) - Karakter laki-laki kalem bijaksana
5. mystery.png (\\uE007) - Karakter misterius bertopeng

Tips:
- Bikin pixel art sederhana (muka/icon, 16x16 px)
- Warna transparan untuk background
- Gunakan site seperti https://www.pixilart.com atau pakai Paint.NET / Aseprite
- Ukuran kecil aja biar muat di chat
- Setelah selesai, compress zip ulang resource pack dan upload ke GitHub lagi
